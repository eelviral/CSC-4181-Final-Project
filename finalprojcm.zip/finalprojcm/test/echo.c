void main(void)
{
	int x;
	x = input();
	print(x);
}



