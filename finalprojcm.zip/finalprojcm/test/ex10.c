int x;
int y[];
int z;
int a[];
