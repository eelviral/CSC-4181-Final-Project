void f(int a){
  int x;
  int g() { return 0; }
}

