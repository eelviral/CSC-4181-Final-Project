int x;
int y;
void z;
int a[10];
int b[9876];
void c[3];
int x[0];